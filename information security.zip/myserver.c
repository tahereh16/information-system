/**
 * server.c
 *
 * The server captures image frames from
 * axis cameras.
 * 
 */
/*************** HEADER FILES **************/
#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <unistd.h>
#include <capture.h>
#include <sys/socket.h>
#include <arpa/inet.h>

/*************** MACRO DEFINITIONS *********/

/* Maximum number of clients */
#define MAX_CLIENTS 5

/* Port number */
#define PORT_NUMBER 5019

/* Buffer size */
#define BUFF_SIZE 1024

/* Bit length used in RSA algorithm */
#define BIT_LENGTH 2048


/******** GLOBAL VARIABLE DECLARATIONS ******/

int p = 0;
int q = 0;
int n = 0;
int phi = 0;
int server_public_key = 0;
int server_private_key = 0;

/******** LOCAL FUNCTION DECLARATIONS ******/

static int server(void);
void rsa();
int rsa_encrypt(int data, int n, int client_public_key);
int rsa_decrypt(int enc_message, int server_private_key, int n);
int calculate_server_public_key(int phi);
int calculate_server_private_key(int server_public_key, int phi);
int check_is_prime(int is_prime);
int randPrime();
int listen_socket(int sock_fd);
int generate_xor_key();

/********** FUNCTION DEFINITIONS ***********/
/**
 * server:
 *
 * Function which handles clients and captures
 * frames.
 *
 * @returns: EXIT_SUCCESS if success.
 *           EXIT_FAILURE if an error occurs. 
 */
static int server(void) {
  int sock_fd;
  int new_sock_fd;
  int pid;
  int n_rev;
  char str[BUFF_SIZE];
  struct sockaddr_in serv_addr;
  struct sockaddr_in cli_addr;
  char *available_resolution;
  void *data;
  size_t send_size;
  size_t size;
  socklen_t cli_len;
  media_stream *stream;
  media_frame *frame;
  int client_pub_key;
  int client_n;
  int width = 0;
  int height = 0;
  int fps = 0;
  int xor_width = 0;
  int xor_height = 0;
  int xor_fps = 0;

  /* Creating socket */
  sock_fd = socket(AF_INET, SOCK_STREAM, 0);

  /* Check socket descriptor status */
  if (sock_fd < 0) {
    syslog(LOG_ERR, "ERROR opening socket");
    return EXIT_FAILURE;
  }

  /* Initialize serv_addr memory to zero. */
  memset(&serv_addr, 0, sizeof(serv_addr));
 
  /* Set internet family to AF_NET (IPv4) */
  serv_addr.sin_family = AF_INET;

  /* Any IP address */
  serv_addr.sin_addr.s_addr = INADDR_ANY;

  /* Port address
   * (Host to network short)
   */
  serv_addr.sin_port = htons(PORT_NUMBER);

  /* Binds server address to socket */
  if (bind(sock_fd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
    syslog(LOG_ERR, "ERROR on binding.");
    return EXIT_FAILURE;
  }

  /* Listen to the socket for clients, Maximum 5 clients */
  listen(sock_fd, MAX_CLIENTS);
  cli_len = sizeof(cli_addr);

  /* Loop handler for clients */
  for (;;) {
    /* Accepting clients in new_sock_fd */
    new_sock_fd = accept(sock_fd, (struct sockaddr *) &cli_addr, &cli_len);

    /* Status of the new sock_fd */
    if (new_sock_fd < 0) {
      syslog(LOG_ERR, "ERROR on accept");
      return EXIT_FAILURE;
    }

    /* Create a child process */
    pid = fork();
    if (pid < 0) {
      syslog(LOG_ERR, "ERROR on fork");
      close(new_sock_fd);
      continue;
    }

    /* Child process created */
    if (pid == 0) {
      int enc_server_n;
      int enc_server_pub_key;
      long htonl_n;
      long htonl_server_public_key;
      int xor_key;
      int enc_xor_key;
      int htonl_enc_xor_key;
      int res_str_len;
      int xor_res_str_len;
      int htonl_xor_res_str_len;
      int j;

      /* Send server public key to the client */
      rsa();

      /* Get client public key */
      client_pub_key = listen_socket(new_sock_fd);
      syslog(LOG_INFO,"Receieved public key from client: %d\n", client_pub_key);

      /* Get client modulus 'n' */
      client_n = listen_socket(new_sock_fd);
      syslog(LOG_INFO,"Receieved 'n' from client: %d\n", client_n);

      /* Send server public key and n value */
      syslog(LOG_INFO,"Sending n: %d, htonl_server_public_key: %d\n", n, server_public_key);
      enc_server_n = rsa_encrypt(n, client_n, client_pub_key);
      enc_server_pub_key = rsa_encrypt(server_public_key, client_n, client_pub_key);
      htonl_n = htonl(enc_server_n);
      htonl_server_public_key = htonl(enc_server_pub_key);
      write(new_sock_fd, &htonl_n, sizeof(htonl_n));
      write(new_sock_fd, &htonl_server_public_key, sizeof(htonl_server_public_key));

      /* Send xor key to client */
      xor_key = generate_xor_key();
      syslog(LOG_INFO,"xor_key: %d\n", xor_key);
      enc_xor_key = rsa_encrypt(xor_key, client_n, client_pub_key);
      htonl_enc_xor_key = htonl(enc_xor_key);
      write(new_sock_fd, &htonl_enc_xor_key, sizeof(htonl_enc_xor_key));

      /* Get the available resolution */
      available_resolution = capture_get_resolutions_list(0);
      syslog(LOG_INFO,"available res: %s", available_resolution);

      /* Pass the available resolution to client */
      res_str_len = strlen(available_resolution);
      xor_res_str_len = res_str_len ^ xor_key;
      htonl_xor_res_str_len = htonl(xor_res_str_len);
      syslog(LOG_INFO, "Resolution string length: %d", res_str_len);
      n_rev = write(new_sock_fd, &htonl_xor_res_str_len, sizeof(htonl_xor_res_str_len));

      /* Check the return status of write function */
      if (n_rev < 0) {
        syslog(LOG_ERR,"Error in writing to socket.");
      } else {
        syslog(LOG_INFO,"Write successfull.");
      }

      unsigned char xor_send_resolution[res_str_len];
      for (j = 0; j < res_str_len; j++) {
        xor_send_resolution[j] = ((unsigned char*) available_resolution)[j] ^ xor_key;
      }
      n_rev = write(new_sock_fd, xor_send_resolution, res_str_len);

      /* Check the return status of write function */
      if (n_rev < 0) {
        syslog(LOG_ERR,"Error in writing to socket.");
      } else {
        syslog(LOG_INFO,"Write successfull.");
      }

      /* Free the memory allocated for available resolution */
      free(available_resolution);

      /* Get user resolution and fps */
      xor_width = listen_socket(new_sock_fd);
      xor_height = listen_socket(new_sock_fd);
      xor_fps = listen_socket(new_sock_fd);

      /* Xor with xor key to get the correct resolution and fps */
      width = xor_width ^ xor_key;
      height = xor_height ^ xor_key;
      fps = xor_fps ^ xor_key;

      /* Form a string using user resolution and fps.
       * Append this str if any other data needed.
       */
      snprintf(str, sizeof(str), "resolution=%dx%d&fps=%d", width, height, fps);
      syslog(LOG_INFO, "Argument to capture open stream: %s", str);

      /* Capture the stream */
      stream = capture_open_stream(IMAGE_JPEG, str);

      /* Loops to number of frames, default 10 */
      while(1) {
        /* Get the frame information */
		        frame = capture_get_frame(stream);

        /* Get the frame data */
        data = capture_frame_data(frame);

        /* Get the frame size */
        size = capture_frame_size(frame);

        /* XOR the data size */
        int image_size = ((int) size) ^ xor_key;
        send_size = htonl(image_size);

        /* Send the xor'd image data size */
        syslog(LOG_INFO, "Sending image size: %d", image_size);
        write(new_sock_fd, &send_size, sizeof(send_size));
        syslog(LOG_INFO, "Sending image size: %d succeeded", image_size);

        /* Xor the image data. */
        unsigned char enc_image[size];
        for (j = 0; j < size; j++) {
          enc_image[j] = ((unsigned char*) data)[j] ^ xor_key;
        }

        /* Send the xor'd image data to client */
		syslog(LOG_INFO, "Sending image ");
        write(new_sock_fd, enc_image, size);
		syslog(LOG_INFO, "Sending image succeed ");

        /* Free the allocated memory */
        capture_frame_free(frame);

        
      }

      /* Close the stream */
      capture_close_stream(stream);

      /* Close the new sock_fd */
      close(new_sock_fd);
    }
 
else {
      /* Close the new sock_fd */
      close(new_sock_fd);
    }
  }

  /* Close server socket */
  close(sock_fd);
 
  return EXIT_SUCCESS;
}

/**
 * main:
 *
 * Main function which triggers the
 * server function.
 *
 * @returns: EXIT_SUCCESS if success.
 *           EXIT_FAILURE if failure.
 */
int main(void) {

  if (!server()) {
    goto out;
  }

  return EXIT_SUCCESS;

out:
  return EXIT_FAILURE;
}


/**
 * rsa:
 *
 * Initialize rsa algorthim parameters.
 *
 * @returns: None.
 */
void rsa() {
  do {
    p = rand() % BIT_LENGTH;
  } while (!check_is_prime(p));

  do {
    q = rand() % BIT_LENGTH;
  } while (!check_is_prime(q));

  n = p * q;
  phi = (p - 1) * (q - 1);
  server_public_key = calculate_server_public_key(phi);
  server_private_key = calculate_server_private_key(server_public_key, phi);

  syslog(LOG_INFO, "Two prime numbers p = %d and q = %d", p, q);
  syslog(LOG_INFO, "n value (p * q) = %d", n);
  syslog(LOG_INFO, "phi value(p - 1) * (q - 1) = %d", phi);
  syslog(LOG_INFO, "Public key n = %d,  e = %d", n, server_public_key);
  syslog(LOG_INFO, "Private key n = %d, d = %d", n, server_private_key);

   /* Enable the following prints if you want to debug server rsa works fine.
    * If you have enabled the following lines, then 2650 should be the decrypted message.
    */
#if 0
  long int enc_message = rsa_encrypt(7856, n, server_public_key);
  long int dec_message = rsa_decrypt(enc_message, server_private_key, n);

  syslog(LOG_INFO,"Decrypted message: %ld\n", dec_message);
#endif
}

/**
 * listen_socket:
 *
 * Listens socket to receive data from client.
 *
 * @returns: Client data in host byte order.
 */
int listen_socket(int sock_fd) {
  int j = 0;
  unsigned char buffer[BUFF_SIZE];
  int bytes_read;
  unsigned long int nw_byte_order;

  do {
    bytes_read = recv(sock_fd, &buffer[j], 1, 0);

    if (bytes_read == -1) {
      break;
    }

    if (bytes_read == 0) {
      break;
    }

    j++;
  } while (j <= 3);

  nw_byte_order = ((unsigned long int) (buffer[0] << 24))
                | ((unsigned long int) (buffer[1] << 16))
                | ((unsigned long int) (buffer[2] << 8))
                | ((unsigned long int) (buffer[3]));

  return (int)le32toh(nw_byte_order);
}

/**
 * generate_xor_key:
 *
 * Generates xor key.
 *
 * @returns: A random key for xor.
 */
int generate_xor_key() {
  return (rand() % BIT_LENGTH);
}

/**
 * calculate_server_public_key:
 *
 * Calculate the server public key.
 *
 * @returns: public key
 */
int calculate_server_public_key(int phi_s) {
  int i;

  for (i = 2; i < phi_s; i++) {
    if (check_is_prime(i) == 0) {
      /* This is not prime. Continue loop. */
      continue;
    }
    if (phi_s % i == 0) {
      /* This is not coprime. Continue loop. */
      continue;
    }
    break;
  }

  /* Return the coprime*/
  return i;
}

/**
 * calculate_server_private_key:
 *
 * Calculate the server private key.
 *
 * @returns: private key
 */
int calculate_server_private_key(int public_key, int phi_p) {
  int i;
  public_key = public_key % phi_p;

  for (i = 1; i < phi_p; i++) {
    if ((public_key*i) % phi_p == 1) {
      break;
    }
  }
  return i;
}

/**
 * rsa_encrypt:
 *
 * RSA encrypt function.
 *
 * @returns: Encrypted data.
 */
int rsa_encrypt(int data, int n_enc, int public_key) {
  int j = 0;
  long long int cipher = 1;

  for (j = 0; j < public_key; j++) {
    cipher = cipher * data % n_enc;
  }

  return (int)cipher;
}

/**
 * rsa_decrypt:
 *
 * RSA decrypt function.
 *
 * @returns: Decrypted data.
 */
int rsa_decrypt(int encrypted_data, int private_key, int n_dec) {
  int j = 0;
  long long int decrypted_data = 1;

  for (j = 0; j < private_key; j++) {
    decrypted_data = decrypted_data * encrypted_data % n_dec;
  }

  return (int)decrypted_data;
}

/**
 * check_is_prime:
 *
 * Checks if the given number is prime.
 *
 * @returns: 0 if not prime, 1 if prime.
 */
int check_is_prime(int is_prime) {
  int i;

  for(i = 2; i < is_prime; i++){
    if((is_prime % i) == 0) {
      return 0;
    }
  }

  return 1;
}
