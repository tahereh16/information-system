package source;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.List;
import java.io.BufferedInputStream;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class AxisClientThread implements Runnable {
  public static int port;
  public static String serverName;
  private String threadName;
  private int threadId;
  private static List<ClientInformation> clientInformationList;
  public int i;
  public int p = 0;
  public int q = 0;
  public long n = 0;
  public int phi = 0;
  public long client_public_key = 0;
  public long client_private_key = 0;
  public int xor_key;

  public AxisClientThread(String threadName, int threadId) {
    this.threadName = threadName;
    this.threadId = threadId;
  }

  public int randInt(int min, int max) {
    Random rand = new Random();
    int randomNum = rand.nextInt((max - min) + 1) + min;

    return randomNum;
  }

  public boolean checkIsPrime(int isprime) {
    int i;

    for(i = 2; i < isprime; i++){
        if((isprime % i) == 0) {
            return false;
        }
    }

    return true;
  }

  public void rsa() {
    int temp;

    while(true) {
      temp = randInt(1000, 2048);

      if(checkIsPrime(temp)) {
        p = temp;
        break;
      }
    }

    while(true) {
      temp = randInt(1000, 2048);

      if(checkIsPrime(temp)) {
          q = temp;
          break;
      }
    }

    n = p * q;
    phi = (p - 1) * (q - 1);
    client_public_key = calculate_client_public_key(phi);
    client_private_key = calculate_client_private_key(client_public_key, phi);

    System.out.println( "Two prime numbers p = " + p + " and q = "+q);
    System.out.println( "n value (p * q) = " + n);
    System.out.println( "phi value(p - 1) * (q - 1) = " + phi);
    System.out.println( "Public key n = " + n + " e = " + client_public_key);
    System.out.println( "Private key for" + threadName + " " +threadId + " n = " + n + " d = " + client_private_key);
  }

  public int calculate_client_public_key(int phi) {
    int i;

    for (i = 2; i < phi; i++) {
      if (isprime(i) == 0) {
        /* This is not prime. Continue loop. */
        continue;
      }
      if (phi % i == 0) {
        /* This is not coprime. Continue loop. */
        continue;
      }
      break;
    }

    /* Return the coprime */
    return i;
  }

  public int calculate_client_private_key(long public_key, int phi) {
    int i;
    public_key = public_key % phi;

    for (i = 1; i < phi; i++) {
      if ((public_key*i) % phi == 1) {
        break;
      }
    }

    return i;
  }

  public long encrypt(int data, long n, long public_key) {
    int j = 0;
    long cipher = 1;

    for (j = 0; j < public_key; j++) {
      cipher = cipher * data % n;
    }

    return cipher;
  }

  public long decrypt(long encrypted_data, long private_key, long n) {
    int j = 0;
    long decrypted_data = 1;

    for (j = 0; j < private_key; j++) {
      decrypted_data = decrypted_data * encrypted_data % n;
    }

    return decrypted_data;
  }

  public int isprime(int is_prime) {
    int i;

    for(i = 2; i < is_prime; i++){
      if((is_prime % i) == 0) {
        return 0;
      }
    }

    return 1;
  }

  @Override
  public void run() {
    System.out.println(this.threadName + " " + this.threadId + " thread started...");
    JLabel jLabel = null;
    try {
      System.out.println("Connecting to " + serverName + " on port " + port);
      Socket client = new Socket(serverName, port);
      System.out.println("Just connected to " + client.getRemoteSocketAddress());

      /* Initialise rsa algo */
      rsa();

      /* Send client public key and keyN */
      DataOutputStream output = new DataOutputStream(client.getOutputStream());
      output.writeInt((int)client_public_key);
      output.writeInt((int)n);

      /* Receive server public key */
      DataInputStream receive_from_server = new DataInputStream(new BufferedInputStream(client.getInputStream()));
      long enc_server_n = receive_from_server.readInt();
      long server_n =  decrypt(enc_server_n, client_private_key, n);
      System.out.println("Server 'N' key:" + server_n + " enc_server_n: " + enc_server_n);
      long enc_server_public_key = receive_from_server.readInt();
      long server_public_key = decrypt(enc_server_public_key, client_private_key, n);
      System.out.println("Server public key:" + server_public_key + " enc_server_public_key: " + enc_server_public_key);

      /* Receieve xor key from server. */
      xor_key = (int)decrypt(receive_from_server.readInt(), client_private_key, n);
      System.out.println("xor_key: " + xor_key);

      /* Receieve resolution string length. */
      int xor_res_string_length = receive_from_server.readInt();
      int res_string_length = xor_res_string_length ^ xor_key;
      System.out.println("Resolution string length: " + res_string_length);

      byte[] res_byte_data = new byte[res_string_length];
      int loop = 0;
      while (true) {
        int res = receive_from_server.read(res_byte_data, loop, res_string_length - loop);
        loop = loop + res;
        if (loop == res_string_length) {
            break;
        }
      }

      /* Xor the resolution string */
      byte[] resolution_xor = new byte[res_byte_data.length];
      for (int xx = 0; xx < res_byte_data.length; xx++) {
        resolution_xor[xx] = (byte) (res_byte_data[xx] ^ xor_key);
      }
      String resolution_str = new String(resolution_xor);
      System.out.println("Available resolution: " + resolution_str);

      /*System.out.println("Enter resolution: ");
      Scanner res = new Scanner(System.in);
      String resolution = res.nextLine();

      System.out.println("Enter fps (between 1 - 30): ");
      Scanner frequency = new Scanner(System.in);
      String fps = frequency.nextLine();*/

      String resolution = clientInformationList.get(threadId).getResolution();
      String fps = clientInformationList.get(threadId).getFps();

      DataOutputStream output_2 = new DataOutputStream(client.getOutputStream());
      String[] parts = resolution.split("x");
      String width = parts[0];
      String height = parts[1];

      System.out.println("Sending width: " + width + " Height: " + height + "fps: " + fps + " to server.");
      int xor_width = Integer.parseInt(width) ^ xor_key;
      int xor_height = Integer.parseInt(height) ^ xor_key;
      int xor_fps = Integer.parseInt(fps) ^ xor_key;

      output_2.writeInt(xor_width);
      output_2.writeInt(xor_height);
      output_2.writeInt(xor_fps);

      try {
        InputStream in = client.getInputStream();
        DataInputStream data = new DataInputStream(in);

        while (true) {
          int encrypted_image_size = receive_from_server.readInt();
          int size = encrypted_image_size ^ xor_key;
          System.out.println("Size of image: " + size);

          byte[] image_byte_data = new byte[size];
          int counter = 0;
          while (true) {
            int read = receive_from_server.read(image_byte_data, counter, size - counter);
            counter = counter + read;
            if (counter == size) {
                break;
            }
          }
          byte[] decrypted_image = new byte[image_byte_data.length];
          for (int x = 0; x < image_byte_data.length; x++) {
            decrypted_image[x] = (byte) (image_byte_data[x] ^ xor_key);
          }

          System.out.println("Refreshing the Image");
          InputStream tempInputStream = new ByteArrayInputStream(decrypted_image);
          BufferedImage image = ImageIO.read(tempInputStream);

          if (jLabel != null) {
            jLabel.setIcon(new ImageIcon(image));
            jLabel.repaint();
          } else {
            jLabel = AxisFileReader.showImagePane(image);
          }
        }
      } catch(Exception e) {
          e.printStackTrace();
      }
      client.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
  }

  public static void fillServerNameAndPort(String[] args) {
    System.out.println("IP is " + args[0]);
    System.out.println("Port is " + args[1]);

    AxisClientThread.serverName = args[0];
    AxisClientThread.port = Integer.parseInt(args[1]);
  }


  public static void setClientInformationList(List<ClientInformation> clientInformationList) {
    AxisClientThread.clientInformationList = clientInformationList;
  }
}

